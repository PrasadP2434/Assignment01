package stoodeoPages;

public class BlogPage {

}
